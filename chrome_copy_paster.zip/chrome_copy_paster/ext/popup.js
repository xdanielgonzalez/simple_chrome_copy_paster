<!-- FIRST PAGE -->

document.getElementById("copy").addEventListener("click", () => {
  console.log("I have been clicked")
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    console.log("I have made it to before sending the message")
    chrome.tabs.sendMessage(tabs[0].id, {
      type: "copy"
    }, function(response){      
        console.log(response.status);
    });
  });
 chrome.storage.sync.get(
    ["webContent"],
    function(result){
    document.getElementById("copiedWebContent").value = result.webContent;
  })
});

document.getElementById("save").addEventListener("click", () => {
  console.log("Hey you clicked save too hard be gentle buddy")
  chrome.storage.sync.set({
    webContent: document.getElementById('copiedWebContent').value
  }, function() {
    console.log("Saved!")
  })
})
<!-- SECOND PAGE -->

document.getElementById("load").addEventListener("click", () => {
  console.log("Hey you clicked load")
  chrome.storage.sync.get([
    "webContent"
], function(result) {
    document.getElementById("webContentToBePasted").value = result.webContent;
  });
});

document.getElementById("paste").addEventListener("click", () => {
	console.log("Hey you clicked paste")
	chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
		console.log("I made it to the beginning of query")
    chrome.tabs.sendMessage(tabs[0].id, {
			type: "paste",
			dataToBePasted: document.getElementById('webContentToBePasted').value,
		}, function(response) {
			console.log(response.status);
		});
	});
});


// this is the part of the copy that needs to actually copy before trying to paste it into the box 

//   console.log("Okay I just copied the web content, im ready to save/present it in the popup")
//   chrome.storage.sync.get(
//     ["webContent"],
//     function(result){
//     document.getElementById("copiedWebContent").value = result.webContent;
//   })
//   console.log("Data save succcess")