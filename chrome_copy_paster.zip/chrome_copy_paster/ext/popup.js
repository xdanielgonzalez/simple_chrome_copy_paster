<!-- FIRST PAGE -->

document.getElementById("copy").addEventListener("click", () => {
  console.log("I have been clicked")
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.tabs.sendMessage(tabs[0].id, {
      type: "copy"
    }, function(response){      
        console.log(response.status);
    });
  });
 chrome.storage.sync.get(
    ["webContent"],
    function(result){
    document.getElementById("copiedWebContent").value = result.webContent;
  })
});

document.getElementById("save").addEventListener("click", () => {
  chrome.storage.sync.set({
    webContent: document.getElementById('copiedWebContent').value
  }, function() {
    console.log("Saved!")
  })
})
<!-- SECOND PAGE -->

document.getElementById("load").addEventListener("click", () => {
  console.log("Hey you clicked load")
  chrome.storage.sync.get([
    "webContent"
], function(result) {
    document.getElementById("webContentToBePasted").value = result.webContent;
  });
});

document.getElementById("paste").addEventListener("click", () => {
	chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.tabs.sendMessage(tabs[0].id, {
			type: "paste",
			dataToBePasted: document.getElementById('webContentToBePasted').value,
		}, function(response) {
			console.log(response.status);
		});
	});
});


